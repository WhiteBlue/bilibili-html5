<?php

namespace App\Http\Controllers;

use App\Models\Save;
use App\Models\Sort;
use App\Models\User;
use Guzzle\Service\Client;
use Illuminate\Http\Request as BaseRequest;
use Guzzle\Http\Message\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Input;
use Laravel\Lumen\Routing\Controller;
use Symfony\Component\Translation\Tests\StringClass;

/**
 * Created by PhpStorm.
 * User: WhiteBlue
 * Date: 15/7/8
 * Time: 下午9:06
 */
class HomeController extends Controller
{

    public function index()
    {
        $list = null;
        if (!Cache::has('index_list')) {
            $list = array();

            foreach (Sort::all() as $sort) {
                $innerList = array();
                $innerList['sort'] = $sort;
                $innerList['list'] = $sort->saves()->take(4)->get();

                array_push($list, $innerList);
            }

            Cache::forever('index_list', $list);
        } else {
            $list = Cache::get('index_list');
        }


        return view('pusher.index')->with('list', $list);
    }


    public function about()
    {
        return view('pusher.about');
    }


    public function aboutMe()
    {
        return view('pusher.aboutMe');
    }

    //定时任务
    public function pump()
    {
        $client = new Client();
        $request = new Request('GET', 'http://api.bilibili.cn/index');
        $response = $client->send($request, ['timeout' => 2]);
        $json = json_decode($response->getBody());

        $count = 0;

        foreach ($json as $type => $value) {
            $sort = Sort::where('type', '=', $type)->first();
            if ($sort != null) {
                foreach ($value as $id => $content) {
                    if (is_object($content)) {
                        if (Save::where('aid', '=', $content->aid)->first() == null) {
                            $save = new Save();
                            $save->aid = $content->aid;
                            $save->title = $content->title;
                            if (strlen($content->description) > 70) {
                                $save->content = mb_substr($content->description, 0, 70, 'utf-8') . '....';
                            } else {
                                $save->content = $content->description;
                            }
                            $save->href = 'http://www.bilibili.com/video/AV' . $content->aid;
                            $save->img = $content->pic;
                            $sort->saves()->save($save);
                            $count++;

                            $sort->update=date('Y:m:d');
                            $sort->save();
                        }
                    }
                }
            }
        }

        Cache::forget('index_list');

        return 'update : ' . $count . ' saves.';
    }

}




