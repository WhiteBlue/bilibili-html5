<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * Created by PhpStorm.
 * User: WhiteBlue
 * Date: 15/7/9
 * Time: 上午11:09
 */
class Log extends Model
{
    protected $table = 'logs';
}