@extends('pusher.layout')


@section('content')

    <div class="row">

        <div class="panel panel-default">
            <div class="panel-body">
                <h2>关于 "Bili Pusher" </h2>

                <p>作者一时脑洞大开的产物，未完成填坑中...有兴趣不妨关注一下</p>

                <p><a class="btn btn-primary btn-lg" href="#" role="button">Git</a></p>
            </div>

        </div>

    </div>


@endsection